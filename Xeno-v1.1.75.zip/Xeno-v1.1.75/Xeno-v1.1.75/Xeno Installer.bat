@echo off

start "" /min "%~dp0system\Updater.bat"


exit
